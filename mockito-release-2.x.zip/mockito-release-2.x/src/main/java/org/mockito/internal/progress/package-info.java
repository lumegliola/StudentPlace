/*
 * Copyright (c) 2007 Mockito contributors
 * This program is made available under the terms of the MIT License.
 */

/**
 * Mocking progress stateful classes.
 */
package org.mockito.internal.progress;
